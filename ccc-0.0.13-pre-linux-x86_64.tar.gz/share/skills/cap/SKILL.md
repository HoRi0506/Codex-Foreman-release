---
name: cap
description: Enter the current user request through Codex-Cli-Captain so host Codex runs the captain-first LongWay loop instead of answering locally.
metadata:
  short-description: Captain LongWay loop entry
---

# $cap

Use when the operator invokes `$cap`. Remove the literal token and route the
remaining request through CCC.

## Public Contract

- `$cap` is the public entry point into CCC orchestration.
- CCC owns the persisted LongWay, task cards, checklist, fan-in, status, and
  restart handoff for the request.
- `$cap` works without host `/plan` or `/goal`; those host surfaces are optional
  affordances only.
- Host `/plan` can help with planning, but it does not replace CCC
  PLAN_SEQUENCE.
- Host `/goal` can act as an outer objective hint, but it does not replace CCC
  LongWay, checklist, fan-in, status, or completion gates.
- Operator-facing output should use the operator's language. Stored LongWay text
  should stay in English.
- Continue work from CCC status and checklist truth, not from hidden host state.
- If a plan, proposed plan, or LongWay was produced through `$cap`, any later
  request to implement, execute, continue, or apply that plan still belongs to
  CCC even if the operator's follow-up text does not include the literal `$cap`
  token. Do not execute such follow-ups directly; route them through CCC or ask
  the operator to confirm CCC execution.
- When presenting a CCC-generated plan or LongWay for later approval, include a
  copyable follow-up instruction that preserves the public entrypoint, for
  example `$cap Execute this approved LongWay: ...`.
- Internal routing, lifecycle, fan-in, fallback, context, and compatibility
  rules belong in CCC memory or persisted captain guidance, not in this public
  skill contract.
